<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="utf-8">
    <title>Landing Page</title>
</head>
<body>
    
    <h1>Ledenadministratie sportvereniging Health</h1>
    <h2>U kunt <a href="/index.php/login">hier</a> inloggen met uw rol en wachtwoord.</h2>

</body>
</html>