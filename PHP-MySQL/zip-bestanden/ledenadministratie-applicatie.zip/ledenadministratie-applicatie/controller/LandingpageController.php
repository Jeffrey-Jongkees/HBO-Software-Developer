<?php

require_once 'model/sport.php';

class LandingPageController {
    public function index() {
        require_once 'view/landingpage.php';
    }
}
?>